import tkinter as tk
from tkinter import ttk, messagebox
import joblib
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.metrics import roc_curve, roc_auc_score

# --- Cargar modelos ---
modelos_por_tipo = {
    "Clasificación": {
        "SVM": joblib.load("modelos/clasificacion/modelo_svm.pkl"),
        "Random Forest": joblib.load("modelos/clasificacion/modelo_rf.pkl"),
        "Regresión Logística": joblib.load("modelos/clasificacion/modelo_log.pkl")
    },
    "Regresión": {
        "SVM": joblib.load("modelos/regresion/modelo_svm.pkl"),
        "Random Forest": joblib.load("modelos/regresion/modelo_rf.pkl"),
        "Regresión Lineal": joblib.load("modelos/regresion/modelo_log.pkl")
    }
}

datos_por_tipo = {
    "Clasificación": ("datos/X_test_clasificacion.pkl", "datos/y_test_clasificacion.pkl"),
    "Regresión": ("datos/X_test_regresion.pkl", "datos/y_test_regresion.pkl")
}

# --- Función para actualizar campos según tipo ---
def actualizar_campos(*args):
    for widget in frame_inputs.winfo_children():
        widget.destroy()

    tipo = tipo_var.get()

    if tipo == "Clasificación":
        crear_input("Granadas Letales", "lethal")
        crear_input("Granadas No Letales", "nonlethal")
        crear_input("Kills por Ronda", "kills")

    elif tipo == "Regresión":
        for campo in [
            ("Asistencias", "assist"),
            ("Headshots", "head"),
            ("Tiempo Vivo", "alive"),
            ("Uso SMG", "smg"),
            ("Uso Rifle", "ar"),
            ("Uso Sniper", "sniper"),
            ("Uso Pesadas", "heavy"),
            ("Uso Pistola", "pistol")
        ]:
            crear_input(campo[0], campo[1])

# --- Crear un campo de entrada ---
entries = {}
def crear_input(label, key):
    tk.Label(frame_inputs, text=label, bg="#f4f4f4").pack()
    entry = tk.Entry(frame_inputs, width=20)
    entry.pack(pady=3)
    entries[key] = entry

# --- Mostrar curva ROC ---
def mostrar_roc(modelo, X_test, y_test, canvas_antiguo):
    if canvas_antiguo:
        canvas_antiguo.get_tk_widget().destroy()

    try:
        if hasattr(modelo, "predict_proba"):
            y_score = modelo.predict_proba(X_test)[:, 1]
        else:
            y_score = modelo.decision_function(X_test)

        fpr, tpr, _ = roc_curve(y_test, y_score)
        auc = roc_auc_score(y_test, y_score)

        fig = plt.Figure(figsize=(5, 4), dpi=100)
        ax = fig.add_subplot(111)
        ax.plot(fpr, tpr, label=f"AUC = {auc:.2f}", color="blue")
        ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
        ax.set_title("Curva ROC")
        ax.set_xlabel("Falsos Positivos")
        ax.set_ylabel("Verdaderos Positivos")
        ax.legend()

        canvas = FigureCanvasTkAgg(fig, master=ventana)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)
        return canvas

    except Exception as e:
        print("Error ROC:", e)
        return None

# --- Función de predicción ---
def hacer_prediccion():
    tipo = tipo_var.get()
    modelo_nombre = modelo_var.get()
    modelo = modelos_por_tipo[tipo][modelo_nombre]

    try:
        if tipo == "Clasificación":
            datos = pd.DataFrame([{
                'RLethalGrenadesThrown': float(entries['lethal'].get()),
                'RNonLethalGrenadesThrown': float(entries['nonlethal'].get()),
                'RoundKills': float(entries['kills'].get())
            }])
        else:
            datos = pd.DataFrame([{
                'TotalRoundAssists_by_Match': float(entries['assist'].get()),
                'TotalRoundHeadshots_by_Match': float(entries['head'].get()),
                'TimeAlive_by_Match': float(entries['alive'].get()),
                'TotalPrimarySMG_Use_by_Match': float(entries['smg'].get()),
                'TotalPrimaryAssaultRifle_Use_by_Match': float(entries['ar'].get()),
                'TotalPrimarySniperRifle_Use_by_Match': float(entries['sniper'].get()),
                'TotalPrimaryHeavy_Use_by_Match': float(entries['heavy'].get()),
                'TotalPrimaryPistol_Use_by_Match': float(entries['pistol'].get())
            }])

        X_test_file, y_test_file = datos_por_tipo[tipo]
        X_test = joblib.load(X_test_file)
        y_test = joblib.load(y_test_file)

        pred = modelo.predict(datos)[0]

        if tipo == "Clasificación":
            mensaje = f"{modelo_nombre} predice: "
            mensaje += "✅ SOBREVIVE (1)" if pred == 1 else "❌ NO SOBREVIVE (0)"
            messagebox.showinfo("Resultado", mensaje)
            global canvas_roc
            canvas_roc = mostrar_roc(modelo, X_test, y_test, canvas_roc)

        else:
            messagebox.showinfo("Resultado", f"{modelo_nombre} estima: {pred:.2f} kills por partida")

    except Exception as e:
        messagebox.showerror("Error", f"Error en predicción: {e}")

# --- Ventana principal ---
ventana = tk.Tk()
ventana.title("Predicción ML Inteligente")
ventana.geometry("650x700")
ventana.configure(bg="#f4f4f4")

# Título
tk.Label(ventana, text="Predicción Inteligente", font=("Helvetica", 16, "bold"), bg="#f4f4f4").pack(pady=10)

# Dropdowns
frame_dropdown = tk.Frame(ventana, bg="#f4f4f4")
frame_dropdown.pack(pady=10)

tipo_var = tk.StringVar(value="Clasificación")
tipo_dropdown = ttk.Combobox(frame_dropdown, textvariable=tipo_var, values=["Clasificación", "Regresión"], state="readonly")
tipo_dropdown.grid(row=0, column=0, padx=10)
tipo_dropdown.bind("<<ComboboxSelected>>", actualizar_campos)

modelo_var = tk.StringVar(value="SVM")
modelo_dropdown = ttk.Combobox(frame_dropdown, textvariable=modelo_var, values=["SVM", "Random Forest", "Regresión Logística"], state="readonly")
modelo_dropdown.grid(row=0, column=1, padx=10)

# Inputs
frame_inputs = tk.Frame(ventana, bg="#f4f4f4")
frame_inputs.pack(pady=10)

# Botón
tk.Button(ventana, text="Predecir", command=hacer_prediccion, bg="#4CAF50", fg="white", font=("Arial", 12, "bold")).pack(pady=15)

# Canvas para ROC
canvas_roc = None

# Iniciar campos según tipo
actualizar_campos()
ventana.mainloop()
